tinyMCE.addI18n({en:{
cookieJar:{
desc : 'Drop an Affiliate Cookie'
}}});
