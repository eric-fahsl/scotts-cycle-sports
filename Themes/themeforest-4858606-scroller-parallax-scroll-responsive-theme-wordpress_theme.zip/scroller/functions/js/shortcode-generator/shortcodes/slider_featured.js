tmnfShortcodeMeta={
	attributes:[
			{
				label:"Slider Portfolio",
				id:"category",
				help:"Enter category name (slug) (lowercase)."
			},
			{
				label:"Number of posts",
				id:"posts_number",
				help:"Enter number."
			}
			],
	defaultContent:"",
	shortcode:"slider_featured"
};
