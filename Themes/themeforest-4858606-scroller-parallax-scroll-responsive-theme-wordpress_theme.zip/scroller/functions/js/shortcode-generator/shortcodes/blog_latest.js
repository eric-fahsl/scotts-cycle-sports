tmnfShortcodeMeta={
	attributes:[
			{
				label:"Number of posts",
				id:"posts_number",
				help:"Enter number."
			}
			],
	defaultContent:"",
	shortcode:"blog_latest"
};
