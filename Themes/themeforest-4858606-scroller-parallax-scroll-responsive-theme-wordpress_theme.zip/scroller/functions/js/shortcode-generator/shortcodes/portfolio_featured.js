tmnfShortcodeMeta={
	attributes:[
			{
				label:"Featured Portfolio",
				id:"category",
				help:"Enter category name (lowercase)."
			},
			{
				label:"Number of posts",
				id:"posts_number",
				help:"Enter number."
			}
			],
	defaultContent:"",
	shortcode:"portfolio_featured"
};
