<?php
/*---------------------------------------------------------------------------------*/
/* Twitter widget */
/*---------------------------------------------------------------------------------*/
class Twitter extends WP_Widget {

   function Twitter() {
	   $widget_ops = array('description' => 'Add your Twitter feed to widget area.' );
       parent::WP_Widget(false, __('Themnific - Twitter Stream', 'themnific'),$widget_ops); 
	   
	   			if ( is_active_widget( false, false, $this->id_base, true ) ) {
				wp_enqueue_script('jquery.tweet', get_template_directory_uri() .'/js/jquery.tweet.js','','', true);
			}     
   }
   
   function widget($args, $instance) {  
    extract( $args );
   	$title = $instance['title'];
    $limit = $instance['limit']; if (!$limit) $limit = 5;
	$username = $instance['username'];
	$unique_id = $args['widget_id'];
	?>
		<?php echo $before_widget; ?>
        <?php if ($title) echo $before_title . $title . $after_title; ?>
        <div class="lasttwit">
        <h2 class="widget inn widget-single"><a href="http://twitter.com/<?php echo esc_attr( $username ); ?>" >@<?php echo esc_attr($username ); ?> &raquo;</a></h2>
		<div class="tweets"></div>
		</div>	
		<script type='text/javascript'> 
      jQuery(document).ready(function($) {
        $(".tweets").tweet({
          join_text: "auto",
          username: "<?php echo $username; ?>",
          avatar_size: 40,
          count: <?php echo $limit; ?>,
          auto_join_text_default: "", 
          auto_join_text_ed: "",
          auto_join_text_ing: "",
          auto_join_text_reply: "",
          auto_join_text_url: "",
          loading_text: "loading tweets..."
        });
      })      
    </script>	
        <?php echo $after_widget; ?>
        
   		
	<?php
   }

   function update($new_instance, $old_instance) {                
       return $new_instance;
   }

   function form($instance) { 
   		$defaults = array('title' => '', 'limit' => '', 'username' => '');
		$instance = wp_parse_args((array) $instance, $defaults);       
   
       $title = esc_attr($instance['title']);
       $limit = esc_attr($instance['limit']);
	   $username = esc_attr($instance['username']);
       ?>
       <p>
	   	   <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','themnific'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo esc_attr($title); ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
       </p>
       <p>
	   	   <label for="<?php echo $this->get_field_id('username'); ?>"><?php _e('Username:','themnific'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('username'); ?>"  value="<?php echo esc_attr($username); ?>" class="widefat" id="<?php echo $this->get_field_id('username'); ?>" />
       </p>
       <p>
	   	   <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _e('Limit:','themnific'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('limit'); ?>"  value="<?php echo esc_attr($limit); ?>" class="" size="3" id="<?php echo $this->get_field_id('limit'); ?>" />

       </p>
      <?php
   }
   
} 
register_widget('Twitter');
?>