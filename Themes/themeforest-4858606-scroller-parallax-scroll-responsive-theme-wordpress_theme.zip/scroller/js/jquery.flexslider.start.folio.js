jQuery(window).load(function() {
/*global jQuery:false */
"use strict";

jQuery('.folioslider').flexslider({
	slideshow: true,
	slideshowSpeed: 7000,
	animationDuration: 600,
	smoothHeight: true
});
	
});