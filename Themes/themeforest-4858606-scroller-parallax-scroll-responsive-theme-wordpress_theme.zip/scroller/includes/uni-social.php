<ul class="social-menu">
<?php if (get_option('themnific_socials_rss') == "") {} else { ?>
<li class="sprite-rss"><a class="mk-social-rss" title="Rss Feed" href="<?php echo get_option('themnific_socials_rss');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_googleplus') == "") {} else { ?>
<li class="sprite-google"><a class="mk-social-googleplus" title="Google+" href="<?php echo get_option('themnific_socials_googleplus');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_dl') == "") {} else { ?>
<li class="sprite-delicious"><a class="mk-social-delicious" title="Delicious" href="<?php echo get_option('themnific_socials_dl');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_ya') == "") {} else { ?>
<li class="sprite-yahoo"><a class="mk-social-yahoo" title="Yahoo!" href="<?php echo get_option('themnific_socials_ya');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_sp') == "") {} else { ?>
<li class="sprite-stumbleupon"><a class="mk-social-stumbleupon" title="Stumbleupon" href="<?php echo get_option('themnific_socials_sp');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_sk') == "") {} else { ?>
<li class="sprite-skype"><a class="mk-social-skype" title="Skype" href="<?php echo get_option('themnific_socials_sk');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_behance') == "") {} else { ?>
<li class="sprite-behance"><a class="mk-social-behance" title="Behance" href="<?php echo get_option('themnific_socials_behance');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_my') == "") {} else { ?>
<li class="sprite-myspace"><a class="mk-social-myspace_alt" title="MySpace" href="<?php echo get_option('themnific_socials_my');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_la') == "") {} else { ?>
<li class="sprite-lastfm"><a class="mk-social-lastfm" title="Last FM" href="<?php echo get_option('themnific_socials_la');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_li') == "") {} else { ?>
<li class="sprite-linkedin"><a class="mk-social-linkedin" title="LinkedIn" href="<?php echo get_option('themnific_socials_li');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_fl') == "") {} else { ?>
<li class="sprite-flickr"><a class="mk-social-flickr" title="Flickr" href="<?php echo get_option('themnific_socials_fl');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_de') == "") {} else { ?>
<li class="sprite-deviantart"><a class="mk-social-deviantart" title="Deviant Art" href="<?php echo get_option('themnific_socials_de');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_tu') == "") {} else { ?>
<li class="sprite-tumblr"><a class="mk-social-tumblr" title="Tumblr" href="<?php echo get_option('themnific_socials_tu');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_vi') == "") {} else { ?>
<li class="sprite-vimeo"><a class="mk-social-vimeo" title="Vimeo" href="<?php echo get_option('themnific_socials_vi');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_yo') == "") {} else { ?>
<li class="sprite-youtube"><a class="mk-social-youtube" title="You Tube" href="<?php echo get_option('themnific_socials_yo');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_tw') == "") {} else { ?>
<li class="sprite-twitter"><a class="mk-social-twitter-alt" title="Twitter" href="<?php echo get_option('themnific_socials_tw');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_fa') == "") {} else { ?>
<li class="sprite-facebook"><a class="mk-social-facebook" title="Facebook" href="<?php echo get_option('themnific_socials_fa');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_pinterest') == "") {} else { ?>
<li class="sprite-pinterest"><a class="mk-social-pinterest" title="Pinterest" href="<?php echo get_option('themnific_socials_pinterest');?>"></a></li><?php } ?>

<?php if (get_option('themnific_socials_instagram') == "") {} else { ?>
<li class="sprite-instagram"><a class="mk-social-photobucket" title="Instagram" href="<?php echo get_option('themnific_socials_instagram');?>"></a></li><?php } ?>

</ul>