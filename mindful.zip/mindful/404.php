<?php get_header(); ?>		
		<div id="middle">
			<div id="pageHead">
				<h1><?php _e('Page Not Found', 'themetrust'); ?></h1>
			</div>						 
		<div id="content" class="threeFourth clearfix">
			<p><?php _e("Sorry, but what you're looking for could not be found.", 'themetrust'); ?></p> 
		</div>
		</div>	
<?php get_footer(); ?>