<?php get_header(); ?>
	
		<div id="pageHead">
			<h1><?php _e('Page Not Found', 'themetrust'); ?></h1>
		</div>
							 
		<div id="content" class="threeFourths clearfix">
			<div class="page clearfix">
			<div class="inside">
				<p><?php _e("Sorry, but what you're looking for could not be found.", 'themetrust'); ?></p>
			</div>
			</div> 
		</div>
			
<?php get_footer(); ?>