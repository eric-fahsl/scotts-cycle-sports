<h3>Widget Area</h3>
<p>This is an area for widgets. You can add and edit widgets from the WordPress admin.</p>				 
<p><a class="action" href="<?php bloginfo('url'); ?>/wp-admin/widgets.php">Customize Widgets</a></p>