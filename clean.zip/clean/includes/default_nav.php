<ul class="sf-menu clearfix" >					
	<li class="current_page_item"><a href="<?php bloginfo('url'); ?>/wp-admin/nav-menus.php">Create the Main Menu</a></li>
</ul>