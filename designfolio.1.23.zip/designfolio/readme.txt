== Designfolio Readme ==

Designfolio created by David Gwyer, and Scott Bolinger
Website: http://www.presscoders.com

Designfolio is distributed under the terms of the GNU GPL.

All Designfolio theme files including PHP, CSS, JavaScript, and image files are distributed under the terms of the GNU GPL.

*Theme Support*

Official Designfolio supprt forum (free sign-up):
http://www.presscoders.com/contact

Once signed up you will receive forum login details by e-mail.

*Setup and Tutorials*

* Designfolio main page information: http://www.presscoders.com/designfolio/
* Installation and setup: http://www.presscoders.com/designfolio-setup

*Upgrade to Designfolio Pro!

Like the free version of Designfolio? Then why not try out the Pro version:
http://www.presscoders.com/designfolio/#buy

