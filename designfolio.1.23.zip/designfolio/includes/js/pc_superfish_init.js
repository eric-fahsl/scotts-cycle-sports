jQuery(document).ready(function($) {
	$('nav ul.menu').superfish({
		animation:   {opacity:'show', height:'show'},
		dropShadows: false,
		speed:       'fast',
        delay:       750
	});
});