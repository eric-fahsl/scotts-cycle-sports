/* Custom code for fitvids. */
jQuery(document).ready(function($) {
	$("#container").fitVids();
});